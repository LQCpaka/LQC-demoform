<?php
    $hsA = $_GET["hsA"];
    $hsB = $_GET["hsB"];

    echo "Tong 2 so: ". $hsA+$hsB;

?>