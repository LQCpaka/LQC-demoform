<?php
    $myArr = ['HTML', 'CSS', 'JS'];

?>
<ul>
    <li><?php echo $myArr[0]; ?></li>
    <li><?php echo $myArr[1]; ?></li>
    <li><?php echo $myArr[2]; ?></li>
</ul>