<?php
 $a = 5;
 $b = 10;
 echo"Ket Qua tong la ", $a+$b;

?>